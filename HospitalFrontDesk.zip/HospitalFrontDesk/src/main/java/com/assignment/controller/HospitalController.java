/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.controller;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.annotation.AccessType;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.assignment.HospitalMain;
import com.assignment.exceptionhandling.BedsNotAvailableException;
import com.assignment.exceptionhandling.BookingException;
import com.assignment.exceptionhandling.HospitalNotFoundException;
import com.assignment.exceptionhandling.ParameterNotFoundException;
import com.assignment.exceptionhandling.SpecialistNotFoundException;
import com.assignment.model.Booking;
import com.assignment.model.SpecialistList.Specialist;
import com.assignment.service.HospitalService;
import com.assignment.service.HospitalServiceException;

/**
 * Controller Class HospitalController.
 */
@RestController
public class HospitalController {

	private static final Logger LOGGER = LoggerFactory.getLogger(HospitalController.class);

	@Autowired
	HospitalService hospitalService;

	@Autowired
	RestTemplate restTemplate;

	/**
	 * Rest template.
	 *
	 * @return the rest template
	 */
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	/** The get specialist url. */
	@Value("${service.getSpecialist}")
	private String getSpecialistUrl;

	/**
	 * Gets the specialist. Request which gets the list of specialists based on
	 * input parameters like hospitalName and specialistType This mapping request is
	 * Cache Configured.
	 *
	 * @param hospitalName   the hospital name
	 * @param specialistType the specialist type
	 * @return List of specialists matching the input parameters both in XML and
	 *         JSON format
	 * @throws SpecialistNotFoundException the specialist not found exception
	 * @throws HospitalServiceException    the hospital service exception
	 * @throws ParameterNotFoundException  the parameter not found exception
	 * @throws HospitalNotFoundException   the hospital not found exception
	 */
	@Cacheable("specialistList")
	@RequestMapping(value = ("${service.getSpecialist}"), method = RequestMethod.GET, produces = { "application/json",
			"application/xml" })
	public List<Specialist> getSpecialist(@Value("${value.requirementOne.hospitalName}") String hospitalName,
			@Value("${value.requirementOne.specialistType}") String specialistType) throws SpecialistNotFoundException,
			HospitalServiceException, ParameterNotFoundException, HospitalNotFoundException {
		System.out.println("If this is printed once on multiple hits to request it is cached data being displayed.");

		// If input parameter for hospitalName not given throw
		// ParameterNotFoundException
		if (hospitalName == null || "".equalsIgnoreCase(hospitalName)) {
			throw new ParameterNotFoundException("Hospital Name not provided.");
		}
		// If input parameter for specialistType not given throw
		// ParameterNotFoundException
		if (specialistType == null || "".equalsIgnoreCase(specialistType)) {
			throw new ParameterNotFoundException("Specialist Type not provided.");
		}
		try {
			// Service call to search for specialists according to given hospitalName and
			// specialistType
			List<Specialist> spct = hospitalService.getSpecialists(hospitalName, specialistType);
			return spct;
		} catch (HospitalNotFoundException e) {
			LOGGER.error("Invalid Hospital Name! Please check the provided Hospital Name!", e);
			throw new HospitalNotFoundException(e.getMessage());
		} catch (SpecialistNotFoundException e) {
			LOGGER.error("Specialist Not Found.", e);
			throw new SpecialistNotFoundException(e.getMessage());

		}
	}

	/**
	 * Checks for available appointment and returns booking details
	 *
	 * @param specialistName the specialist name
	 * @param appointmentDay the appointment day
	 * @param patientName    the patient name
	 * @return the booking
	 * @throws SpecialistNotFoundException the specialist not found exception
	 * @throws HospitalServiceException    the hospital service exception
	 * @throws ParameterNotFoundException  the parameter not found exception
	 * @throws BookingException            the booking exception
	 */
	@RequestMapping(value = ("${service.bookAppointment}"), method = RequestMethod.GET, produces = { "application/json"})
	public Booking getBooking(@RequestParam(name = "specialistName", required = false) String specialistName,
			@RequestParam(name = "appointmentDay", required = false) String appointmentDay,
			@RequestParam(name = "patientName", required = false) String patientName)
			throws ParameterNotFoundException, BookingException, SpecialistNotFoundException {

		// If input parameter for specialistName not given throw
		// ParameterNotFoundException
		if (specialistName == null || "".equalsIgnoreCase(specialistName)) {
			throw new ParameterNotFoundException("Specialist Name not provided.");
		}

		// If input parameter for appointmentDay not given throw
		// ParameterNotFoundException
		if (appointmentDay == null || "".equalsIgnoreCase(appointmentDay)) {
			throw new ParameterNotFoundException("Appointment Day not provided.");
		}
		// If input parameter for patientName not given throw ParameterNotFoundException
		if (patientName == null || "".equalsIgnoreCase(patientName)) {
			throw new ParameterNotFoundException("Patient Name not provided.");
		}
		try {
			// Calling Booking service to book appointment
			Booking booking = hospitalService.getBooking(specialistName, appointmentDay, patientName);
			if (booking == null) {
				throw new BookingException("Booking failed!");
			}
			return booking;
		} catch (SpecialistNotFoundException e) {
			LOGGER.error("Specialist Not Found.", e);
			throw new SpecialistNotFoundException(e.getMessage());

		}
	}

	/**
	 * Gets the number of beds available for a particular hospital based on patient
	 * discharge information
	 *
	 * @param hospitalName the hospital name
	 * @return the number of beds
	 * @throws SpecialistNotFoundException the specialist not found exception
	 * @throws HospitalServiceException    the hospital service exception
	 * @throws ParameterNotFoundException  the parameter not found exception
	 * @throws HospitalNotFoundException   the hospital not found exception
	 * @throws BedsNotAvailableException
	 */
	@RequestMapping(value = ("${service.getNumberOfBeds}"), method = RequestMethod.GET)
	public String getNumberOfBeds(@RequestParam(name = "hospitalName", required = false) String hospitalName)
			throws SpecialistNotFoundException, HospitalServiceException, ParameterNotFoundException,
			HospitalNotFoundException, BedsNotAvailableException {

		// If input parameter for hospitalName not given throw
		// ParameterNotFoundException
		if (hospitalName == null || "".equalsIgnoreCase(hospitalName)) {
			LOGGER.error("Hospital Name not provided");
			throw new ParameterNotFoundException("Hospital Name not provided");
		}
		try {

			int count = hospitalService.getNumberOfBeds(hospitalName);
			// If count is zero throw exception
			if (count == 0) {

				LOGGER.error("Beds Not Available in Hospital!");
				throw new BedsNotAvailableException("Beds Not Available in Hospital!");
			}
			return "Number of Beds Available is = " + count;
		} catch (HospitalNotFoundException e) {
			throw new HospitalNotFoundException(e.getMessage());
		}
	}

	/**
	 * Test Requirement One using RestTemplate
	 *
	 * @return the Specialist Entity URL is formed from application.properties file
	 */
	@RequestMapping(value = ("${service.testGetSpecialist}"))
	public List<Specialist> testRequirement1(@Value("${server.url}") String url, @Value("${server.port}") String port,
			@Value("${value.requirementOne.hospitalName}") String hospitalName,
			@Value("${value.requirementOne.specialistType}") String specialistType) {

		// Form final url to test requirement one

		String finalURL = url.concat(":").concat(port).concat(getSpecialistUrl).concat("?").concat("hospitalName=")
				.concat(hospitalName).concat("&").concat("specialistType=").concat(specialistType);
		LOGGER.info("Final URL is: " + finalURL);

		HttpHeaders headers = new HttpHeaders();

		// RestTemplate to process both XML and JSON
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML));

		HttpEntity<List<Specialist>> entity = new HttpEntity<>(headers);
		ResponseEntity<List<Specialist>> response = restTemplate.exchange(finalURL, HttpMethod.GET, entity,
				new ParameterizedTypeReference<List<Specialist>>() {
				});
		HttpStatus statusCode = response.getStatusCode();
		if (statusCode == HttpStatus.OK) {
			List<Specialist> listSpecialist = response.getBody();
			return listSpecialist;
		}
		return null;
	}
}
