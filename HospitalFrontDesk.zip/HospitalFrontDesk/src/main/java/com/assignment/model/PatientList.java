/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

// TODO: Auto-generated Javadoc
/**
 * Configuration Class PatientList to fetch patient details from properties file
 */
@Configuration
@PropertySource("classpath:hospitalAndPatientDetails.properties")
@ConfigurationProperties(prefix = "patient")
public class PatientList 
{
	
	/** The patient list. */
	private List<Patient> patientList = new ArrayList<>();

	/**
	 * Instantiates a new patient list.
	 */
	public PatientList()
	{}

	/**
	 * Gets the patient list.
	 *
	 * @return the patient list
	 */
	public List<Patient> getPatientList() {
		return patientList;
	}

	/**
	 * Find by hospital id and status.
	 *
	 * @param hospitalId 
	 * @param status 
	 * @return the list of patients found from hospital id and status
	 */
	public List<Patient> findByHospitalIdAndStatus(int hospitalId, String status) 
	{
		List<Patient> valList = new ArrayList<>();
		for(Patient p: patientList)
		{
			if(p.getHospitalId() == hospitalId && status.equalsIgnoreCase(p.getStatus()))
			{
				valList.add(p);
			}
		}
		return valList;
	}
	
	/**
	 * POJO Class Patient.
	 */
	public static class Patient {
		
		private String name;
		
		private String status;
		
		private int hospitalId;

		/**
		 * Instantiates a new patient.
		 */
		public Patient() {}

		/**
		 * Gets the patientname.
		 *
		 * @return the name
		 */
		public String getName() {
			return name;
		}

		/**
		 * Sets the patient name.
		 *
		 * @param name 
		 */
		public void setName(String name) {
			this.name = name;
		}

		/**
		 * Gets the hospital discharge status.
		 *
		 * @return the status
		 */
		public String getStatus() {
			return status;
		}

		/**
		 * Sets the hospital discharge status.
		 *
		 * @param status
		 */
		public void setStatus(String status) {
			this.status = status;
		}

		/**
		 * Gets the hospital id.
		 *
		 * @return the hospital id
		 */
		public int getHospitalId() {
			return hospitalId;
		}

		/**
		 * Sets the hospital id.
		 *
		 * @param hospitalId 
		 */
		public void setHospitalId(int hospitalId) {
			this.hospitalId = hospitalId;
		}
	
	}
}
