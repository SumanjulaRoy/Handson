/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.service;

/**
 *  Class HospitalServiceException.
 */
public class HospitalServiceException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -470180507998010368L;

	/**
	 * Instantiates a new hospital service exception.
	 */
	public HospitalServiceException() {
		super();
	}

	/**
	 * Instantiates a new hospital service exception.
	 *
	 * @param message the message
	 */
	public HospitalServiceException(final String message) {
		super(message);
	}
}
