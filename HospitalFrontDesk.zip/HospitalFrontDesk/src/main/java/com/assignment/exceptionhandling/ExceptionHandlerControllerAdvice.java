/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.exceptionhandling;

import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Class ExceptionHandlerControllerAdvice to handle exceptions and show exception details in response body.
 */
@ControllerAdvice
public class ExceptionHandlerControllerAdvice {

	/**
	 * Handle specialist not found exception
	 *
	 * @param exception 
	 * @param request 
	 * @return the exception response
	 */
	@ExceptionHandler(SpecialistNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public @ResponseBody ExceptionResponse handleResourceNotFound(final SpecialistNotFoundException exception,
			final HttpServletRequest request) {

		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.callerURL(request.getRequestURI());

		return error;
	}

	/**
	 * Handle generic exception.
	 *
	 * @param exception 
	 * @param request 
	 * @return the exception response
	 */
	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public @ResponseBody ExceptionResponse handleException(final Exception exception,
			final HttpServletRequest request) {

		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.callerURL(request.getRequestURI());

		return error;
	}
	
	/**
	 * Handle Hospital Not Found Exception
	 *
	 * @param exception 
	 * @param request 
	 * @return the exception response
	 */
	@ExceptionHandler(HospitalNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public @ResponseBody ExceptionResponse handleResourceNotFound(final HospitalNotFoundException exception,
			final HttpServletRequest request) {

		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.callerURL(request.getRequestURI());

		return error;
	}
	
	/**
	 * Handle Parameter Not Found Exception
	 *
	 * @param exception 
	 * @param request 
	 * @return the exception response
	 */
	@ExceptionHandler(ParameterNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public @ResponseBody ExceptionResponse handleResourceNotFound(final ParameterNotFoundException exception,
			final HttpServletRequest request) {

		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.callerURL(request.getRequestURI());

		return error;
	}
	
	/**
	 * Handle Booking Exception
	 *
	 * @param exception 
	 * @param request 
	 * @return the exception response
	 */
	@ExceptionHandler(BookingException.class)
	@ResponseStatus(value = HttpStatus.NOT_IMPLEMENTED)
	public @ResponseBody ExceptionResponse handleResourceNotFound(final BookingException exception,
			final HttpServletRequest request) {

		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.callerURL(request.getRequestURI());

		return error;
	}
	
	/**
	 * Handle Beds Not Available Exception
	 *
	 * @param exception 
	 * @param request 
	 * @return the exception response
	 */
	@ExceptionHandler(BedsNotAvailableException.class)
	@ResponseStatus(value = HttpStatus.FORBIDDEN)
	public @ResponseBody ExceptionResponse handleResourceNotFound(final BedsNotAvailableException exception,
			final HttpServletRequest request) {

		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.callerURL(request.getRequestURI());

		return error;
	}

}
