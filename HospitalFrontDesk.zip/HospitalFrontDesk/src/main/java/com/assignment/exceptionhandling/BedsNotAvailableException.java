/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.exceptionhandling;

/**
 *  Class BedsNotAvailableException.
 */
public class BedsNotAvailableException extends Exception {

	private static final long serialVersionUID = -9079454849611061074L;

	/**
	 * Instantiates a new beds not available exception.
	 */
	public BedsNotAvailableException() {
		super();
	}

	/**
	 * Instantiates a new beds not available exception.
	 *
	 * @param message the message
	 */
	public BedsNotAvailableException(final String message) {
		super(message);
	}

}
