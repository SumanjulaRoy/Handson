/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.exceptionhandling;

/**
 *  Class ExceptionResponse.
 */
public class ExceptionResponse {

	/** The error message. */
	private String errorMessage;
	
	/** The requested URI. */
	private String requestedURI;

	/**
	 * Gets the error message.
	 *
	 * @return the error message
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * Sets the error message.
	 *
	 * @param errorMessage
	 */
	public void setErrorMessage(final String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * Gets the requested URI.
	 *
	 * @return the requested URI
	 */
	public String getRequestedURI() {
		return requestedURI;
	}

	/**
	 * Caller URL.
	 *
	 * @param requestedURI 
	 */
	public void callerURL(final String requestedURI) {
		this.requestedURI = requestedURI;
	}
}
