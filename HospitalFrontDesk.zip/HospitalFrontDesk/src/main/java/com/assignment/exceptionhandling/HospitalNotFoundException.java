/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.exceptionhandling;

/**
 *  Class HospitalNotFoundException.
 */
public class HospitalNotFoundException extends Exception {

	private static final long serialVersionUID = -9079454849611061074L;

	/**
	 * Instantiates a new hospital not found exception.
	 */
	public HospitalNotFoundException() {
		super();
	}

	/**
	 * Instantiates a new hospital not found exception.
	 *
	 * @param message the message
	 */
	public HospitalNotFoundException(final String message) {
		super(message);
	}

}
